export const menuList=[
    {
        title : "Home",
        url :"/",
        cName:"nav-links",
        icon :"fa-solid fa-house-chimney"
    } ,
    {
        title : "Products",
        url :"/product",
        cName:"nav-links",
        icon :"fa-solid fa-house-chimney"
    } ,
    {
        title : "Wishlist",
        url :"/wishlist",
        cName:"nav-links",
        icon :"fa-solid fa-house-chimney"
    } ,
    {
        title : "Cart",
        url :"/cart",
        cName:"nav-links",
        icon :"fa-thin fa-cart-shopping"
    },
    {
        title : "Sign In",
        url :"/signIn",
        cName:"nav-links-login",
        icon :"fa-thin fa-cart-shopping"
    },
    {
        title : "Logout",
        url :"/logout",
        cName:"nav-links-logout",
        icon :"fa-thin fa-cart-shopping"
    }
]

